###
this file folder which saves vehiclemodel param,for example dynamic vehicle model,and kinematic vehicle model;
###
for the moment ,these vehicle model save in same headfile.

8.31 add novacarmodel.h