/*
 * @Author: your name
 * @Date: 2020-08-31 14:37:03
 * @LastEditTime: 2020-09-10 17:25:52
 * @LastEditors: xiangzhang
 * @Description: In User Settings Edit
 * @FilePath: /review_code/vehiclemodel/novacar.h
 */
#ifndef NOCACAR_H
#define NOCACAR_H

#endif  //