程序编译node
底层：各基本的controller/xx_controller.cpp,math/methods,  
rosnode:存储ros相关功能包，rviz的显示脚本
