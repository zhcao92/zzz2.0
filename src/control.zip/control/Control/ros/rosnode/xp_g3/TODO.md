<!--
 * @Descripttion: 
 * @version: 
 * @Author: xiangzhang
 * @Date: 2020-09-15 20:47:54
 * @LastEditors: xiangzhang
 * @LastEditTime: 2020-09-15 20:48:47
-->
1、底盘通信节点测试
2、速度测试
3、轨迹跟踪测试
