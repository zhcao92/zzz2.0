// init Vehicle co

class VehicleModel {
 private:
  /* data */
 public:
  VehicleModel(/* args */);
  ~VehicleModel();
};

VehicleModel::VehicleModel(/* args */) {}

VehicleModel::~VehicleModel() {}
