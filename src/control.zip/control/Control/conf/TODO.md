configfile will be save here
for example, control param file,and so many....calibration scale